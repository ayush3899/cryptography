/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package crypto;

import java.security.Key;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;


/**
 *
 * @author Ayush Kushwaha
 */
public class AESClient {
    
    private static final String Algo="AES";
    private byte[] keyValue;

    public AESClient(String key) {
        keyValue=key.getBytes();
    }
    
    public String encrypt(String Data) throws Exception{
        Key key=generateKey();
        Cipher c= Cipher.getInstance(Algo);
        c.init(Cipher.ENCRYPT_MODE, key);
        byte[] encValue=c.doFinal(Data.getBytes());
        String encryptedValue=new BASE64Encoder().encode(encValue);
        return encryptedValue;
        
    }
    
    public String decrypt(String encryptedData) throws Exception{
        Key key=generateKey();
        Cipher c=Cipher.getInstance(Algo);
        c.init(Cipher.DECRYPT_MODE,key);
        byte[] decodedValue=new BASE64Decoder().decodeBuffer(encryptedData);
        byte[] decValue=c.doFinal(decodedValue);
        String decryptedValue=new String(decValue);
        return decryptedValue;
    }
    
    private Key generateKey() throws Exception {
         Key key=new SecretKeySpec(keyValue, Algo);
         return key;
    }
    
    public static void main(String [] args)
    {
        try{
            AESClient aes=new AESClient("2gbvdf3b4");
            String encData=aes.encrypt("Ayush Kushwaha");
            System.out.println("Encrypted data= "+encData);
            String decData=aes.decrypt(encData);
            System.out.println("Decrypted Data= "+decData);
        }
        catch (Exception e){
            
        }
    }

    
    
}
